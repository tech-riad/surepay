==== Uniquepay BD payment Gateway ====
Contributors: techmicroofficial
Tags: UniquePay BD, bdpaymentgateway, payment, gateway, bkash, rocket, nagad, upay, cellfin, paypal, stripe, paddle, perfectmoney
Requires at least: 5.2
Tested up to: 6.3.1
Stable Tag: 1.0.0

License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

UniquePay BD Plugin for WooCommerce.

== Description ==

UniquePay BD WooCommerce Plugin. You can receive payment through your personal account with Automation.


* [Life Demo](https://uniquepaybd.com)
* [Need Help?](https://wa.me/message/7YSEUR4RW7SRP1)



===Video Tutorial===
include soon 

== Features ==
*lower price licenses sell
* Digital Product
* Fee SystemCod
* And many more...

== Supported Gateways ==
* bKash
* Rocket
* Nagad
* Upay
* Cellfin
* PaypalStr
* 2checkout
* Multiple Bank
* Sonali Bank
* DBBL Bank
* EBL Bank
* Islamic Bank
* Basic Bank

===positive review===
please give us some positive review 